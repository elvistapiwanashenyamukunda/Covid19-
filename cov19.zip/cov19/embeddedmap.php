<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Google Map</title><input type="text" name="latitude" value="">
    <link rel="stylesheet" href="styles.css">
</head>
<body onload="getLocation();">
    <form class="myForm" action="" methods="post" autocomplete="off">
        <label for="">Name</label>
        <input type="text" name="name" required value=""><br>
        <label for="">Email</label>
        <input type="email" name="email" required value=""><br>
        <input type="text" name="latitude" value="">
        <input type="text" name="longitude" value=""><br>
        <button type="submit" name="submit">Submit</button><br>
    </form>
    <script type="text/javascript">
        function getLocation(){
            if(navigator.geolocation){
                navigator.geolocation.getCurrentPosition(showPosition);
            }
        }
        function showPosition(position) {
            document.querySelector('.myForm input [name = "latitude"]').value = position.coords.latitude;
            document.querySelector('.myForm input [name = "longitude"]').value = position.coords.longitude;
        }
    </script>
</body>
</html>