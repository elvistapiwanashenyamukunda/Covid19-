<?php
    $Username = $_POST['Username'];
    $Password = $_POST['Password'];

    //db con
    $con = new mysqli("localhost","root","","cov19");
    if($con->connect_error){
        die("Connection Error : ".$con->connect_error);
    }else{
        $stmt = $con->prepare("select * from registration where Username = ?");
        $stmt->bind_param("s", $Username);
        $stmt->execute();
        $stmt_result = $stmt->get_result();
        if($stmt_result->num_rows > 0){
            $data = $stmt_result->fetch_assoc();
            if($data['Password'] === $Password){
                echo "Login Successful";
                header('Location:patientpage.php');
            }else{
                echo "Invalid Username or Password";
            }
        }else{
            echo "Invalid Username or Password";
        }
    }
?>