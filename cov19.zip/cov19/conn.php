<?php


$con = mysqli_connect("localhost","root","","cov19");


$scrUserame = mysqli_real_escape_string($con, $_POST['Username']);
$scrPassword = mysqli_real_escape_string($con, $_POST['Password']);
$scrConpass  = mysqli_real_escape_string($con, $_POST['Conpass']);
$scrGender  = mysqli_real_escape_string($con, $_POST['Gender']);
$scrVaccination_Status  = mysqli_real_escape_string($con, $_POST['Vaccination_Status']);
if ($scrPassword!=$scrConpass) {
    # code...
    echo "Sorry password did not match";

}else{
    $ssql = "insert into registration(Username, Password, Conpass, Gender, Vaccination_Status) values ('$scrUserame', '$scrPassword', '$scrConpass', '$scrGender', '$scrVaccination_Status')";
    }

if(mysqli_query($con,$ssql))
{
	echo "Booking was successful, Please proceed to payments....";
}
else
{
	die('Cannot save to database');
}
mysqli_close($con);

/*$sName = "localhost";
$uName = "root";
$pass = "";
$db_name = "cov19";

try{
    $conn = new PDO("mysql:host=$sName;dbname=$db_name", $uName, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch(PDOException $e){
    echo "Connection Failed : ". $e->getMessage()
}*/
?>