<?php
   //include "con1.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>

       <!-- CSS only -->
       <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
</head>
<body style="margin: 50px;">
<h1>My Profile</h1>
    <br>
    <table class="table">
        <thead>
            <th>ID_Number</th>
            <th>Username</th>
            <th>Password</th>
            <th>Conpass</th>
            <th>Gender</th>
            <th>Vaccination_Status</th>
            <th>Action</th>
        </thead>

        <tbody>
            <?php
            $con = mysqli_connect("localhost","root","","cov19");

            if ($con->connect_error){
                die("Connection failed: " . $con->connect_error);
            }

            //read all rows
            $sql = "SELECT * FROM registration";
            $result = $con->query($sql);

            if(!$result){
                die("Invalid query: " . $con->error);
            }

            //read each row
            while($row = $result->fetch_assoc()){
                echo "<tr>
                <td>" . $row["ID_Number"] . "</td>
                <td>" . $row["Username"] . "</td>
                <td>" . $row["Password"] . "</td>
                <td>" . $row["Conpass"] . "</td>
                <td>" . $row["Gender"] . "</td>
                <td>" . $row["Vaccination_Status"] . "</td>
                <td>
                    <a class='btn btn-primary btn-sm' href='testresults.html'>Checkout</a>
                    <a class='btn btn-danger btn-sm' href='vaccinationremainder.html'>Remainder</a>
                    <a class='btn btn-secondary btn-sm' href='cov19.html'>Checkin</a>
                </td>
            </tr>";
            }
          
            ?>
        </tbody>
    </table>
    
</body>
</html>